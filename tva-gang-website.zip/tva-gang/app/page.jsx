'use client'
import { useState } from 'react'
import { ArrowRight, Crown, Crosshair, Shield, Users, Radio, Github, Instagram, MessageCircle, Menu, X, ChevronDown } from 'lucide-react'

const members=[
 {name:'The Founder',rank:'LEADER',tag:'TVA-01',accent:'Founder of the family and final decision maker.'},
 {name:'The Right Hand',rank:'CO-LEADER',tag:'TVA-02',accent:'Keeps the crew moving when the city gets loud.'},
 {name:'Enforcer',rank:'ELITE',tag:'TVA-07',accent:'Field specialist for high-risk RP operations.'},
]

export default function Home(){
 const [menu,setMenu]=useState(false); const [open,setOpen]=useState(null)
 const nav=(id)=>{document.getElementById(id)?.scrollIntoView({behavior:'smooth'});setMenu(false)}
 return <main>
  <div className="grain"/>
  <header className="nav"><div className="brand" onClick={()=>nav('home')}><span className="mark">T</span><div><b>TVA</b><small>GANG / RP COMMUNITY</small></div></div>
   <button className="mobile" onClick={()=>setMenu(!menu)}>{menu?<X/>:<Menu/>}</button>
   <nav className={menu?'open':''}>{['home','about','ranks','lore','contact'].map(x=><button key={x} onClick={()=>nav(x)}>{x}</button>)}<a href="https://github.com/" target="_blank"><Github size={16}/> GitHub</a></nav>
  </header>

  <section id="home" className="hero"><div className="hero-bg"/><div className="hero-content"><div className="eyebrow"><span/> FAN-MADE GTA V RP COMMUNITY</div><h1>ONE FAMILY.<br/><em>ONE LEGACY.</em></h1><p>Welcome to TVA — a fan-made GTA V RP gang community built around loyalty, stories, street-level roleplay and cinematic moments.</p><div className="actions"><button className="primary" onClick={()=>nav('about')}>ENTER THE FAMILY <ArrowRight size={18}/></button><button className="ghost" onClick={()=>nav('lore')}>READ OUR STORY</button></div><div className="stats"><div><b>TVA</b><span>EST. RP COMMUNITY</span></div><div><b>24/7</b><span>STORYLINES</span></div><div><b>100%</b><span>FAN MADE</span></div></div></div><div className="hero-side"><div className="vertical">TVA // LOS SANTOS // RP</div></div></section>

  <section id="about" className="section about"><div className="section-label">01 / WHO WE ARE</div><div className="split"><div><h2>BUILT FOR <span>ROLEPLAY.</span><br/>KNOWN FOR <span>LOYALTY.</span></h2></div><div><p className="lead">TVA is a fictional, fan-made GTA V RP gang identity created for community storytelling. No official affiliation with Rockstar Games, GTA Online, or any GTA RP server is claimed.</p><p>Our focus is character development, crew chemistry, organized scenes, memorable events and a community where every member can contribute to the story.</p><div className="chips"><span><Shield/>LOYALTY</span><span><Crosshair/>DISCIPLINE</span><span><Radio/>STORY</span></div></div></div></section>

  <section id="ranks" className="section dark"><div className="section-label">02 / THE FAMILY</div><div className="section-head"><h2>RANKS & <span>ROLES</span></h2><p>Every position has a purpose. Build reputation through RP, teamwork and consistency.</p></div><div className="cards">{members.map((m,i)=><article className="card" key={m.tag}><div className="num">0{i+1}</div><div className="icon">{i===0?<Crown/>:i===1?<Users/>:<Crosshair/>}</div><h3>{m.rank}</h3><b>{m.name}</b><p>{m.accent}</p><span className="tag">{m.tag}</span></article>)}</div></section>

  <section id="lore" className="section lore"><div className="section-label">03 / TVA STORY</div><div className="lore-grid"><div><h2>THE CITY <span>REMEMBERS.</span></h2><p>TVA started as a small circle of players who wanted more from RP than random encounters. The goal was simple: create a crew identity that makes every session feel like an episode.</p><p>From late-night drives to tense negotiations, every scene adds another page to the family archive.</p></div><div className="timeline">{[['01','THE SPARK','A crew becomes a family.'],['02','THE CODE','Respect the story. Protect the crew.'],['03','THE LEGACY','Make every scene worth remembering.']].map(([n,t,d],i)=><button className="event" key={n} onClick={()=>setOpen(open===i?null:i)}><span>{n}</span><div><b>{t}</b><small>{d}</small>{open===i&&<p>Fan-made lore entry — customize this section with your actual TVA backstory, server events and character canon.</p>}</div><ChevronDown className={open===i?'rot':''}/></button>)}</div></div></section>

  <section id="contact" className="section cta"><div className="section-label">04 / JOIN THE COMMUNITY</div><h2>YOUR STORY<br/><span>STARTS HERE.</span></h2><p>Replace the links below with your real Discord, Instagram and GitHub community pages.</p><div className="socials"><a href="https://discord.com/" target="_blank"><MessageCircle/> Discord</a><a href="https://instagram.com/" target="_blank"><Instagram/> Instagram</a><a href="https://github.com/" target="_blank"><Github/> GitHub</a></div></section>

  <footer><div className="brand"><span className="mark">T</span><div><b>TVA</b><small>FAN-MADE GTA V RP</small></div></div><p>© 2026 TVA Fan Community. Not affiliated with Rockstar Games.</p></footer>
 </main>
}
