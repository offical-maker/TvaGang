import './globals.css'
export const metadata={title:'TVA Gang | GTA V RP Fan Community',description:'Fan-made GTA V RP community website for TVA Gang.'}
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>}
