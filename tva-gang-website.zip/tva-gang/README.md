# TVA Gang — GTA V RP Fan Community

Fan-made community website for TVA Gang. Built with Next.js and designed for GitHub/Vercel deployment.

## Run
npm install
npm run dev

## Customize
Edit `app/page.jsx` for names, ranks, lore and social links; edit `app/globals.css` for visual styling.

> This is a fan-made project and is not affiliated with Rockstar Games or Take-Two Interactive.
